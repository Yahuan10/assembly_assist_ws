# robotiq modbus

Here is the code that grab from the v1.2.0 version of pymodbus.
As the newer version of pymodbus does not work with our device.
